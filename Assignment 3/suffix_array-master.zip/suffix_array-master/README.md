suffix_array
============

C++ Suffix Array Implementation 

CCompilation : 

cmake . && make


